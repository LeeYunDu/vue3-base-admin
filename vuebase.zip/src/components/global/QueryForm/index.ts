import QueryForm from './queryForm.vue'

export default QueryForm
