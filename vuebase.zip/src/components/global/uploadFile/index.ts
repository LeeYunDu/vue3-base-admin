import uploadFile from './index.vue'

export default uploadFile
