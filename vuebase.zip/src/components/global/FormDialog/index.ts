import QueryForm from './formDialog.vue'

export default QueryForm
