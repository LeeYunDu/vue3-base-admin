const defaultProps = {
  label: 'label',
  id: 'id',
  type: 'type',
  children: 'children',
  disabled: 'disabled',
  customize: 'customize'
}

export {
  defaultProps
}
