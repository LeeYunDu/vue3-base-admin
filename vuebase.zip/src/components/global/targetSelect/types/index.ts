export interface tabItem {
  id:string, // 分组ID
  label:string, // 分组名称
  customize?:boolean // 是否是自定义分组
}
