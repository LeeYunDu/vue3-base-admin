import CustomTable from './index.vue'

export default CustomTable
