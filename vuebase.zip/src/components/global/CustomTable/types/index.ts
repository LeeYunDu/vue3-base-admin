export interface tableQuery {
  current:number,
  size:number
}
