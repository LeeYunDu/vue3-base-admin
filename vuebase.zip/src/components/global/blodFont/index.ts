import blodFont from './blodFont.vue'
export default blodFont
