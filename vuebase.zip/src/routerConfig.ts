module.exports = {
  moduleLibrary: {
    moduleChildren: {
      sort: 99, title: '子模块一', redirect: 'noRedirect'
    }
  },
  tests: {
    test11: {
      sort: 99, title: '测试模块011', redirect: 'noRedirect'
    },
    test22: {
      sort: 99, title: '测试模块022', redirect: 'noRedirect'
    },
    test33: {
      sort: 99, title: '测试模块033', redirect: 'noRedirect'
    },
    test44: {
      sort: 99, title: '测试模块044', redirect: 'noRedirect'
    }
  }
}

