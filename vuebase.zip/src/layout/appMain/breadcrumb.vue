<template>
  <div class="breadcrumb-container">
    面包屑功能
  </div>
</template>
<script lang='ts'>
import { defineComponent } from 'vue'

export default defineComponent({

})
</script>
<style lang="scss" scoped>
.breadcrumb-container {
  height: 32px;
  width: 100%;
  position: relative;
  overflow: hidden;
  color: #515a6e;
  background: #f0f0f0;
  padding-top: 10px;
  padding-left: 15px;
  display: block;
  font-size: 12px;
  line-height: 20px;
  background-color: #f0f0f0;
  box-sizing: border-box;
}
</style>
